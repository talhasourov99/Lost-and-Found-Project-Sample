﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

namespace LostFoundSystem.Controllers
{
    public class AccountController : Controller
    {
        // GET: Login page
        public IActionResult Login()
        {
            return View();
        }

        // POST: Login submit
        [HttpPost]
        public IActionResult Login(string username, string password)
        {
            if (username == "admin" && password == "talha")
            {
                HttpContext.Session.SetString("Admin", "true");
                return RedirectToAction("Index", "Dashboard");
            }

            ViewBag.Error = "Invalid username or password";
            return View();
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
    }
}
