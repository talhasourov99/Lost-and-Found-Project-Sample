﻿using Microsoft.AspNetCore.Mvc;
using LostFoundSystem.Models;
using Microsoft.AspNetCore.Http;

namespace LostFoundSystem.Controllers
{
    public class DashboardController : Controller
    {
        private readonly ApplicationDbContext _context;

        public DashboardController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            if (HttpContext.Session.GetString("Admin") != "true")
            {
                return RedirectToAction("Login", "Account");
            }

            ViewBag.Total = _context.Items.Count();
            ViewBag.Lost = _context.Items.Count(i => i.ItemType == "Lost");
            ViewBag.Found = _context.Items.Count(i => i.ItemType == "Found");

            return View();
        }
    }
}
