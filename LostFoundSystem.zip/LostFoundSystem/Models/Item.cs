﻿using System;
using System.Collections.Generic;

namespace LostFoundSystem.Models;
using System.ComponentModel.DataAnnotations;

public class Item
{
    public int ItemId { get; set; }

    [Required]
    public string ItemName { get; set; }

    [Required]
    public string ItemType { get; set; }
}
